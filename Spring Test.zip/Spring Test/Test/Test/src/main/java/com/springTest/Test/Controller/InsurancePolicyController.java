package com.springTest.Test.Controller;

import com.springTest.Test.Entity.InsurancePolicy;
import com.springTest.Test.Service.InsurancePolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InsurancePolicyController {

    @Autowired
    private InsurancePolicyService insurancePolicyService;

    @PostMapping("/policies")
    public InsurancePolicy createPolicy(@RequestBody InsurancePolicy policy) {
        return insurancePolicyService.savePolicy(policy);
    }
}
