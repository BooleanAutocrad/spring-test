package com.springTest.Test.Exception;

import lombok.Getter;

@Getter
public class UserRejectedException extends RuntimeException {
    private final String conditionName;

    public UserRejectedException(String conditionName) {
        super(conditionName);
        this.conditionName = conditionName;
    }
}
