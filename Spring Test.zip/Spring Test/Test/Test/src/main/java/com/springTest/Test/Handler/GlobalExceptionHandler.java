package com.springTest.Test.Handler;

import com.springTest.Test.Exception.UserRejectedException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(UserRejectedException.class)
    public ResponseEntity<String> handleResourceNotDeletedException(UserRejectedException userRejectedException) {
        String message = "The following pre-existing condition can’t be covered with a new policy: " + userRejectedException.getConditionName();
        return new ResponseEntity<>(message, HttpStatus.FORBIDDEN);
    }
}
