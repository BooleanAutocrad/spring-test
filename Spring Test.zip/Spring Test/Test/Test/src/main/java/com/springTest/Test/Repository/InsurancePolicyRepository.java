package com.springTest.Test.Repository;

import com.springTest.Test.Entity.InsurancePolicy;
import org.springframework.data.repository.CrudRepository;

public interface InsurancePolicyRepository  extends CrudRepository<InsurancePolicy, Integer> {

}
