package com.springTest.Test.Service;

import com.springTest.Test.Entity.InsurancePolicy;
import com.springTest.Test.Repository.InsurancePolicyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InsurancePolicyService {

    @Autowired
    private InsurancePolicyRepository insurancePolicyRepository;


    public InsurancePolicy savePolicy(InsurancePolicy policy) {
        return insurancePolicyRepository.save(policy);
    }
}
