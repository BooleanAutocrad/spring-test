package com.springTest.Test.Service;

import com.springTest.Test.Entity.User;
import com.springTest.Test.Exception.UserRejectedException;
import com.springTest.Test.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private static final List<String> REJECTED_CONDITIONS = Arrays.asList("Heart", "Kidney", "Liver", "Brain", "Eyes");

    public User saveUser(User user) {
        for (String condition : REJECTED_CONDITIONS) {
            if (user.getExistingMedicalConditions().contains(condition.toLowerCase())) {
                user.setAccepted(false);
                throw new UserRejectedException(condition);
            }
        }
        user.setAccepted(true);
        return userRepository.save(user);
    }




}
